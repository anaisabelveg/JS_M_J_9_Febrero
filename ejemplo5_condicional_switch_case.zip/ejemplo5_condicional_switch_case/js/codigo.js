function cambiarColor(texto,event){
    // Mostrar el id del boton donde se ha producido el evento
    //alert(event.target.id);
    alert(texto);

    switch (event.target.id) {
        case "btn1":
            event.target.className = "rojo";
            break;

        case "btn2":
            event.target.className = "verde";
            break;

        case "btn3":
            event.target.className = "azul";
            break;
    }
}