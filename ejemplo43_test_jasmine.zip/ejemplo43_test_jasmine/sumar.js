exports.sumarNumeros = function(num1, num2){
    return num1 + num2;
}

exports.restarNumeros = function(num1, num2){
    return num1 - num2;
}