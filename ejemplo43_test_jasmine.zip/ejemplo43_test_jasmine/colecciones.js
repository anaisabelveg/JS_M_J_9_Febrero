let array = new Array();
exports.addElemento = function(elemento){
    array.push(elemento);
}

exports.longitud = function(){
    return array.length;
}