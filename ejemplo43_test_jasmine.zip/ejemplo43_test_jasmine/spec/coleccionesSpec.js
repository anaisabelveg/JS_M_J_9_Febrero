let app = require("../colecciones.js");

describe("prueba_colecciones", function(){
    it("add", function(){
        let sizeAntes = app.longitud();
        app.addElemento("Juan");
        let sizeDespues = app.longitud();
        expect(sizeDespues).toBe(sizeAntes + 1);
    });
});