let app = require("../sumar.js");

// describe() -> lo utilizo para crear una bateria de pruebas
describe('Prueba', function(){

    // Se ejecuta antes de cada prueba
    beforeEach( () => {
        console.log("Ejecutando prueba ------");
    });

    // Diseñar cada prueba unitaria
    it('sumar', function(){
        let resultado = app.sumarNumeros(4,9);
        expect(resultado).toBe(13);
    });

    it('restar', function(){
        let resultado = app.restarNumeros(10,5);
        expect(resultado).toBe(5);
    });
});