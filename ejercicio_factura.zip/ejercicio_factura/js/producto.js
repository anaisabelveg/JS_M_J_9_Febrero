class Producto{

    // propiedades de instancia -> cada instancia tiene una copia
    // de estas propiedades
    id;
    descripcion;
    precio;

    // propiedad de clase -> solo existe una copia y reside en la clase
    static #contador = 0;

    // constructor
    constructor(descripcion, precio){
        this.id = ++Producto.#contador;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    // Para acceder a un recurso estatico debe ser dentro de un
    // contexto estatico
    static getContador(){
        return Producto.#contador;
    }

    // Todas las clases tienen el metodo toString() que devuelve
    // la representacion textual del objeto
    toString(){
        return "ID: " + this.id + " Descripcion: " + this.descripcion
            + " Precio: " + this.precio;
    }

    equals(otro){
        if (this.id === otro.id){
            return true;
        } else {
            return false;
        }
    }

}