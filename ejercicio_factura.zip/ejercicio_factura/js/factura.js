class Factura{

    // propiedades privadas
    #numero;
    #cliente;
    #fecha;
    #productos;

    // propiedades de clase
    static #contador = 0;


    // constructor
    constructor(cliente, fecha, productos){
        this.#numero = ++Factura.#contador;
        this.setCliente(cliente);
        this.setFecha(fecha);
        this.setProductos(productos);
    }

    getNumero(){
        return this.#numero;
    }

    getCliente(){
        return this.#cliente;
    }

    setCliente(cliente){
        if (cliente instanceof Cliente){
            this.#cliente = cliente;
        }
    }

    getFecha(){
        return this.#fecha;
    }

    setFecha(fecha){
        this.#fecha = fecha;
    }

    getProductos(){
        return this.#productos;
    }

    setProductos(productos){
        this.#productos = productos;
    }

    toString(){
        return "Numero: " + this.#numero + " Cliente: " + this.#cliente +
            " Fecha: " + this.#fecha + " Productos: " + this.#productos;
    }

}