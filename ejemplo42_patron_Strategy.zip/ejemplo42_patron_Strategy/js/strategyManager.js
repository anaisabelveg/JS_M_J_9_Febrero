class StrategyManager{

    // Decidir que estrategia utilizamos
    elegir(dato){

        switch (dato) {
            case "A":
                return new StrategyA("Strategy A");
        
            case "B":
                return new StrategyB("Strategy B");
                
            case "C":
                return new StrategyC("Strategy C");
                  
            default:
                break;
        }
    }
}