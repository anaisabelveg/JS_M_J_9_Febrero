class Strategy{

    algoritmo(){}
}