class StrategyB extends Strategy{

    nombre;

    constructor(nombre){
        super();
        this.nombre = nombre;
    }

    algoritmo(){
        console.log(`La estrategia ${this.nombre} ejecuta su algoritmo`);
    }
}