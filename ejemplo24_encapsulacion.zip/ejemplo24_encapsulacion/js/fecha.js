class Fecha{

    // atributos o propiedades PUBLICAS
    dia;
    mes;
    anyo;

    constructor(dia, mes, anyo){
        this.dia = dia;
        this.mes = mes;
        this.anyo = anyo;
    }

    mostrar(){
        return this.dia + "/" + this.mes + "/" + this.anyo;
    }
}