function cargarProvincias(){
    var arrayProvincias = ["Madrid", "Valencia", "Sevilla", "Toledo"];

    for(let indice in arrayProvincias){
        document.getElementById("provincias").innerHTML += 
             "<option value='" +indice +"'>" + arrayProvincias[indice] 
                + "</option>";
    }
}

function cargarPoblaciones(){
    let seleccionado = document.getElementById("provincias").selectedIndex;
    let arrayPoblaciones = null;

    switch (seleccionado) {
        case 1:
            arrayPoblaciones = ["Getafe", "Parla", "Las Rozas"];
            break;
    
        case 2:
            arrayPoblaciones = ["Gandia", "Oliva"];
            break;

        case 3:
            arrayPoblaciones = ["Dos Hermanas", "Espartinas", "Los Palacios"];
            break;

        case 4:
            arrayPoblaciones = ["Talavera", "Trillo"];
            break;
    }

    // Limpiar las opciones anteriores
    document.getElementById("poblaciones").innerHTML = 
        "<option disabled='disabled' selected> --selecciona-- </option>";

    for(let indice in arrayPoblaciones){
        let opt = new Option(arrayPoblaciones[indice], indice);
        document.getElementById("poblaciones").options[parseInt(indice)+1] = opt;
    }
}