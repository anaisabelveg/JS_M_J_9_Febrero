let estiloBorde = false;   // false: no tiene borde, true: si lo tiene
let estiloColor = false;
let estiloSombra = false;

const caja = document.querySelector("#cuadrado");

function borde(){
    if (!estiloBorde){
        document.getElementById("cuadrado").style.border = "3px solid blue";
        estiloBorde = true;
    } else {
        document.getElementById("cuadrado").style.border = "none";
        estiloBorde = false;
    }
}

function color(){
    if (!estiloColor){
        caja.style.backgroundColor = "yellow";
    } else {
        caja.style.backgroundColor = "gainsboro";
    }
    estiloColor = !estiloColor;
}

function sombra(){
    if (!estiloSombra){
        caja.className = "sombra";
    } else {
        caja.className = null;
    }
    estiloSombra = !estiloSombra;
}
