class Publicador{

    subscriptores = new Array();

    constructor(){
        console.log("Se ha creado el publicador");
    }

    // metodo para subscribirse
    subscribe(subscriptor){
        this.subscriptores.push(subscriptor);
    }

    // metodo para borrar la subscripcion
    borrar(subscriptor){
        this.subscriptores = this.subscriptores.filter( (item) => 
            item !== subscriptor
        );
        console.log(`El subscriptor ${subscriptor.nombre} se ha dado de baja`);
    }

    lanzarMensaje(noticia){
        // Se envia la noticia al buzon de todos los subscriptores
        this.subscriptores.forEach( (subscriptor) => {
            subscriptor.buzon(noticia);
        });
    }
}