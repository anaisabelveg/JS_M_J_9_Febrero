class Empleado extends Persona{


    // Propiedad privada
    #sueldo;

    // Constructor
    constructor(nombre, edad, sueldo){
        super(nombre, edad); // Llamamos al constructor de la superclase
        this.setSueldo(sueldo);
    }

    getSueldo(){
        return this.#sueldo;
    }

    setSueldo(sueldo){
        if (sueldo > 800){
            this.#sueldo = sueldo;
        }
    }

    mostrarInfo(){
        // Invocar al metodo de la clase Persona
        return super.mostrarInfo() + " Sueldo: " + this.#sueldo;
    }

}