function funcMatematicas(){
    console.log("logaritmo 1000: " + Math.log(1000));
    console.log("Exponencial de 4: " + Math.exp(4));
    console.log("Raiz de 9: " + Math.sqrt(9));
    console.log("Potencia 2 elevado a 4: " + Math.pow(2,4));
    console.log("Absoluto -56.3456: " + Math.abs(-56.3456));
    console.log("Redondeo baja 4.9: " + Math.floor(4.9));
    console.log("Redondeo alza 4.1: " + Math.ceil(4.1));
    console.log("Redondeo medio 4.9: " + Math.round(4.9));
    console.log("Redondeo medio 4.1: " + Math.round(4.1));
    console.log("Aleatorio: " + Math.random());
    console.log("Coseno de 100: " + Math.cos(100));
    console.log("Maximo: " + Math.max(...[3,9,1,2,8,5,6]));
    console.log("Minimo: " + Math.min(3,9,1,2,8,5,6));
    console.log("PI: " + Math.PI);
    console.log("E: " + Math.E);
    console.log("Area de un circulo: " + (Math.PI * Math.pow(46, 2)));
    with(Math){
        console.log("Area de un circulo: " + (PI * pow(46, 2)));
    }
}

function funcTextos(){
    let texto = "Esto es un texto para probar las funciones String";

    console.log("Caracter unicode 174: " + String.fromCharCode(174));
    console.log("Unicode letra o: " + texto.charCodeAt(3));
    console.log("indexOf posicion letra a: " + texto.indexOf("a"));
    console.log("indexOf siguiente posicion letra a: " + texto.indexOf("a", 19));
    console.log("lastIndexOf posicion letra a: " + texto.lastIndexOf("a"));
    console.log("Longitud del texto: " + texto.length);
    console.log("subcadena substr posicion 3, longitud 6: " + texto.substr(3,6));
    console.log("subcadena substr posicion 3: " + texto.substr(3));
    console.log("subcadena slice pos inicio 3, pos final 6: " + texto.slice(3,6));
    console.log("subcadena slice pos inicio 3: " + texto.slice(3));
    console.log("subcadena substring pos inicio 3, pos final 6: " + texto.substring(3,6));
    console.log("subcadena substring pos inicio 3: " + texto.substring(3));
    console.log("Minusculas: " + texto.toLowerCase());
    console.log("Mayusculas: " + texto.toUpperCase());

    let datos = "16/2/2023".split("/");
    //console.log(typeof datos);
    console.log("Dia: " + datos[0]);
    console.log("Mes: " + datos[1]);
    console.log("Año: " + datos[2]);
}

function funcFechas(){
    let hoy = new Date();

    console.log("Ahora: " + hoy);
    console.log("getTime: " + hoy.getTime());
    console.log("Diferencia horaria: " + hoy.getTimezoneOffset());
    console.log("Dia semana (0-6): " + hoy.getDay());
    console.log("Dia del mes: " + hoy.getDate());
    console.log("Mes (0-11): " + hoy.getMonth());
    console.log("Año 2 digitos: " + hoy.getYear());
    console.log("Año 4 digitos: " + hoy.getFullYear());
    console.log("Horas: " + hoy.getHours());
    console.log("Minutos: " + hoy.getMinutes());
    console.log("Segundos: " + hoy.getSeconds());
    console.log("Milisegundos: " + hoy.getMilliseconds());
}