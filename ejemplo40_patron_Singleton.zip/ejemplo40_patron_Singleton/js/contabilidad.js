class Contabilidad{

    static instance = new Contabilidad();
    libro = Array();

    constructor(){
        console.log("---------------"); // solo se muestra la primera vez
        return Contabilidad.instance;
        // Si ya existe la instancia la devuelve, sino la crea
        /*if (Contabilidad.instance){
            return Contabilidad.instance;
        } else {
            Contabilidad.instance = this;
        }*/
    }

    static getInstance(){
        return Contabilidad.instance;
    }

    anotarAsientos(datos){
        console.log("Anotando en el libro de contabilidad " + datos);
        this.libro.push(datos);
    }


}