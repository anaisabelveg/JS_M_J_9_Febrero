export function longitud(texto){
    return texto.length;
}

function mayusculas(texto){
    return texto.toUpperCase();
}

export function minusculas(texto){
    return texto.toLowerCase();
}

export function buscar(texto, caracter){
    return texto.indexOf(caracter);
}