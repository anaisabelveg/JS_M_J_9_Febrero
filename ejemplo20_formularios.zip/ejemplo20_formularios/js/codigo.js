function completar(){
    var opt = new Option("Master", "master");
    document.getElementById("estudiosTxt").options[4] = opt;
    var opt = new Option("Doctorado", "doctorado");
    document.getElementById("estudiosTxt").options[5] = opt;
}


function mostrar(event){
    // Cancelar el evento submit
    event.preventDefault();

    console.log("Nombre: " + formulario.nombre.value);
    console.log("Apellido: " + formulario.apellido.value);
    console.log("Edad: " + formulario.edad.value);
    console.log("Email: " + formulario.email.value);
    console.log("URL: " + formulario.url.value);
    console.log("Fecha: " + formulario.fecha.value);
    console.log("Sexo: " + formulario.sexo.value);
    console.log("Estudios: " + formulario.estudios.value);

    for(let i in document.getElementById("cursosTxt").options){
        if (document.getElementById("cursosTxt").options[i].selected){
            console.log("Cursos: " + 
                document.getElementById("cursosTxt").options[i].text);
        }
    }

}

