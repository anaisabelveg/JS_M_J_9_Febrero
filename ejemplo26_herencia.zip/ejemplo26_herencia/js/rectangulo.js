class Rectangulo extends Figura{

    // propiedades
    base;
    altura;

    // constructor
    constructor(x, y, base, altura){
        super(x, y);  // Llamamos al constructor de la superclase
        this.base = base;
        this.altura = altura;
    
    }

    // Sobreescribir el metodo area
    area(){
        return this.base * this.altura;
    }

    // Sobreescribir el metodo mostrarDatos
    mostrarDatos(){
        return super.mostrarDatos() +
            " Base: " + this.base + " Altura: " + this.altura;
    }
}