class Circulo extends Figura{

    // propiedad
    radio;

    // constructor
    constructor(x, y, radio){
        super(x,y);   // Llamar al constructor de la superclase
        this.radio = radio;
    }

    // Sobreescribir el metodo area
    area(){
        return Math.PI * Math.pow(this.radio, 2);
    }

    // Sobreescribir el metodo mostrarDatos
    mostrarDatos(){
        // Invocar al metodo sobreescrito
        return super.mostrarDatos() + " Radio: " + this.radio;
    }
}