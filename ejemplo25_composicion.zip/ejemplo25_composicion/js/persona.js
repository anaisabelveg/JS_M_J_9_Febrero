class Persona{

    // propiedades PRIVADAS
    #nombre;
    #edad;
    #sexo;
    #direccion;

    // constructor
    constructor(nombre, edad, sexo, direccion){
        this.setNombre(nombre);
        this.setEdad(edad);
        this.setSexo(sexo);
        this.setDireccion(direccion);
    }

    getNombre(){
        return this.#nombre;
    }

    setNombre(nombre){
        this.#nombre = nombre;
    }

    getEdad(){
        return this.#edad;
    }

    setEdad(edad){
        if (edad > 0){
            this.#edad = edad;
        }
    }

    getSexo(){
        return this.#sexo;
    }

    setSexo(sexo){
        if (sexo == 'H' || sexo == 'M'){
            this.#sexo = sexo;
        }
    }

    getDireccion(){
        return this.#direccion;
    }

    setDireccion(direccion){
        if (direccion instanceof Direccion){
            this.#direccion = direccion;
        }
    }

    mostrar(){
        return "Nombre: " + this.#nombre +
            " Edad: " + this.#edad +
            " Sexo: " + this.#sexo +
            " Direccion: " + this.#direccion.mostrar();
    }
}